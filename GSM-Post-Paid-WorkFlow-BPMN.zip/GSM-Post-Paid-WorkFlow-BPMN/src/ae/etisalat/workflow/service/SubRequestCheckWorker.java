/**
 * 
 */
package ae.etisalat.workflow.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import ae.etisalat.workflow.common.Constants;
import ae.etisalat.workflow.db.DBConnection;
import io.zeebe.client.ZeebeClient;
import io.zeebe.client.ZeebeClientBuilder;
import io.zeebe.client.api.clients.JobClient;
import io.zeebe.client.api.response.ActivatedJob;
import io.zeebe.client.api.subscription.JobHandler;
import io.zeebe.client.api.subscription.JobWorker;
import oracle.jdbc.driver.OracleConnection;

/**
 * @author gpalani
 *
 */
public class SubRequestCheckWorker {

	/**
	 * @param args
	 */
	
	
	public static void main(String[] args) {
		
		ZeebeClientBuilder builder = ZeebeClient.newClientBuilder().brokerContactPoint(Constants.BROKER);
		
		try (ZeebeClient client = builder.build()) {
			
			System.out.println("Opening job worker");
			
			
			final JobWorker workerRegistration1 = client
					.newWorker()
					.jobType(Constants.JOB_PROVISIONING_SYSTEM_CHECK)
					.handler(new GSM_JobHandler())
					.timeout(Duration.ofSeconds(10))
					.open();
			
//			final JobWorker workerRegistration2 = client
//					.newWorker()
//					.jobType(Constants.JOB_PROVISIONING_SYSTEM_CHECK)
//					.handler(new GSM_JobHandler())
//					.timeout(Duration.ofSeconds(10))
//					.open();

			
			
			waitUntilSystemInput("exit");
//			workerRegistration.close();
		}
	}
	
	private static class GSM_JobHandler implements JobHandler {

		@Override
		public void handle(JobClient client, ActivatedJob job) {

			final Map<String, Object> inputVariables = job.getVariablesAsMap();
			final Map<String, Object> outputVariables = new HashMap();
			
			String input1 = (String) inputVariables.get("input1");
			//Integer input2 = (Integer) inputVariables.get("input2");
			String output1 = null;
			
			try {
				OracleConnection conn1 = DBConnection.connect_CMDSRC();
				PreparedStatement stmt = conn1.prepareStatement(Constants.QUERY_STATUS_CHECK);
				stmt.setString(1,input1);
				ResultSet rs = stmt.executeQuery();
				
				while(rs.next()) {
					output1 = rs.getString("STATUS");
					System.out.println("Status :: "+output1);
				}
				
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			client
			.newCompleteCommand(job.getKey())
			.variables(output1)
			.send()
			.join();
		}
		
	}
	
	private static void waitUntilSystemInput(final String exitCode) {
		try(Scanner scanner = new Scanner(System.in)){
			while(scanner.hasNextLine()){
				final String nextLine = scanner.nextLine();
				if(nextLine.contains(exitCode)) {
					return;
				}
			}
		}
	}

}
