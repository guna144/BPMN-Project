/**
 * 
 */
package ae.etisalat.workflow.service;

import io.zeebe.client.ZeebeClient;
import io.zeebe.client.api.events.WorkflowInstanceEvent;

/**
 * @author gpalani
 *
 */
public class DBListener {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		final ZeebeClient client = ZeebeClient.newClientBuilder()
				.brokerContactPoint("DXB00087218:26500")
				.build();
		
		System.out.println("Connected");
		
		final WorkflowInstanceEvent wfInstance = client.newCreateInstanceCommand()
				.bpmnProcessId("GSM_Post_Paid_Process")
				.latestVersion()
				.variables("{\"sub-request-id\": 745040239 }")
				.send()
				.join();
		
		final long workflowInstanceKey = wfInstance.getWorkflowInstanceKey();
		
		System.out.println("Workflow instance created key : "+ workflowInstanceKey);
		
		client.close();
		
		System.out.println("Closed");
		
	}

}
